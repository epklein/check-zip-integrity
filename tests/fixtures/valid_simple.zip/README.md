# Test Fixtures

Place your test archive files in this directory for the test suite to use.

## Required Test Archives

### Valid Archives (Required)

1. **valid_simple.7z**
   - A simple, valid 7z archive
   - Should contain at least one file
   - Should pass integrity check

2. **valid_simple.zip**
   - A simple, valid ZIP archive
   - Should contain at least one file
   - Should pass integrity check

3. **valid_multi.7z.001** and **valid_multi.7z.002**
   - A multi-volume 7z archive (at least 2 volumes)
   - Create using: `7z a -v10m valid_multi.7z <files>`
   - Should pass integrity check when 7z command is available

4. **valid_multi.z01**, **valid_multi.z02**, and **valid_multi.zip**
   - A multi-volume ZIP archive (at least 2 volumes)
   - Create using: `zip -s 10m valid_multi.zip <files>`
   - Should pass integrity check when 7z command is available

### Corrupted Archives (Optional but Recommended)

5. **corrupted.7z**
   - A corrupted 7z archive
   - Create by truncating a valid archive or modifying random bytes
   - Should fail integrity check

6. **corrupted.zip**
   - A corrupted ZIP archive
   - Create by truncating a valid archive or modifying random bytes
   - Should fail integrity check

## Creating Test Archives

### Simple Archives

```bash
# Create simple 7z archive
echo "test content" > test.txt
7z a valid_simple.7z test.txt

# Create simple ZIP archive
zip valid_simple.zip test.txt
```

### Multi-volume Archives

```bash
# Create multi-volume 7z (10MB volumes)
7z a -v10m valid_multi.7z <large-files>

# Create multi-volume ZIP (10MB volumes)
zip -s 10m valid_multi.zip <large-files>
```

### Corrupted Archives

```bash
# Create corrupted 7z by truncating
cp valid_simple.7z corrupted.7z
truncate -s -100 corrupted.7z

# Create corrupted ZIP by truncating
cp valid_simple.zip corrupted.zip
truncate -s -100 corrupted.zip
```

## Notes

- Tests will skip if the required archive files are not present
- Multi-volume tests will skip if 7z command is not available
- Corrupted archive tests will skip if those files are not present
